<?php
require_once 'koneksi.php'; // Menggunakan file koneksi

// Membuat objek koneksi
$koneksi = new Koneksi();
$db = $koneksi->getKoneksi();

// Mendapatkan ID produk dari URL
$id = isset($_GET['id']) ? $_GET['id'] : null;

if (!$id) {
    echo "<script>alert('ID Produk tidak ditemukan.');window.location='data_barang.php';</script>";
    exit;
}

// Mengambil data produk berdasarkan ID
$query = "SELECT * FROM produk WHERE id = ?";
$stmt = $db->prepare($query);

if (!$stmt) {
    die("Query gagal dipersiapkan: " . $db->error);
}

$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $data = $result->fetch_assoc();
} else {
    echo "<script>alert('Produk tidak ditemukan.');window.location='data_barang.php';</script>";
    exit;
}
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Edit Produk</title>
    <style type="text/css">
      /* Global style */
      * {
        font-family: "Trebuchet MS", sans-serif;
        box-sizing: border-box;
      }

      /* Header */
      h1 {
        text-transform: uppercase;
        color: #112F91; /* Warna teks utama */
        text-align: center;
        margin-top: 20px;
        font-size: 2em;
        letter-spacing: 1px;
      }

      /* Button styling */
      button, .cancel-button {
        background-color: #112F91; /* Warna utama */
        color: #ffffff; /* Warna teks */
        padding: 12px 20px;
        font-size: 16px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.3s ease;
        width: 48%; /* Lebar tombol */
        margin: 10px 1%; /* Jarak antar tombol */
        text-align: center;
      }

      button:hover {
        background-color: #0D2674; /* Warna lebih gelap saat hover */
      }

      .cancel-button {
        background-color: #112F91; /* Warna merah untuk tombol cancel */
      }

      .cancel-button:hover {
        background-color: #c9302c; /* Warna merah lebih gelap saat hover */
      }

      /* Input and select styling */
      label {
        margin-bottom: 5px;
        font-weight: bold;
        color: #112F91;
      }

      input, select {
        padding: 10px;
        width: 100%;
        background: #f8f8f8;
        border: 2px solid #ccc;
        outline-color: #112F91;
        border-radius: 5px;
        margin-bottom: 15px;
      }

      input:focus, select:focus {
        border-color: #112F91;
        background-color: #fff;
      }

      /* Form container */
      .base {
        width: 400px;
        padding: 25px;
        margin: 50px auto;
        background: #ededed; /* Warna latar form */
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
      }

      .base div {
        margin-bottom: 20px;
      }

      /* Button container */
      .button-container {
        display: flex;
        justify-content: space-between; /* Membuat tombol terpisah */
        align-items: center;
      }
    </style>
  </head>
  <body>
      <center>
        <h1>Edit Produk</h1>
      </center>
      <form method="POST" action="edit_proses.php" enctype="multipart/form-data">
        <section class="base">
          <input type="hidden" name="id" value="<?php echo $data['id']; ?>" />
          <div>
            <label>Nama Produk</label>
            <input type="text" name="nama_produk" value="<?php echo htmlspecialchars($data['nama_produk']); ?>" required />
          </div>
          <div>
            <label>Deskripsi</label>
            <input type="text" name="deskripsi" value="<?php echo htmlspecialchars($data['deskripsi']); ?>" />
          </div>
          <div>
            <label>Jenis Produk</label>
            <select name="jenis_produk" required>
              <option value="">-- Pilih Jenis Produk --</option>
              <option value="banner" <?php echo $data['jenis_produk'] == 'banner' ? 'selected' : ''; ?>>Banner</option>
              <option value="sticker" <?php echo $data['jenis_produk'] == 'sticker' ? 'selected' : ''; ?>>Sticker</option>
            </select>
          </div>
          <div>
            <label>Harga Jual</label>
            <input type="text" name="harga_jual" value="<?php echo htmlspecialchars($data['harga_jual']); ?>" required />
          </div>
          <div>
            <label>Gambar Produk (Kosongkan jika tidak ingin dirubah)</label>
            <input type="file" name="gambar_produk" />
          </div>
          <div>
            <button type="submit">Update</button>
            <a href="data_barang.php" class="cancel-button">Cancel</a>
          </div>
        </section>
      </form>
  </body>
</html>
