<?php
include 'koneksi.php';

$koneksiObj = new Koneksi();
$koneksi = $koneksiObj->getKoneksi();

// Ambil data transaksi yang sudah bayar
$sql = "SELECT * FROM transaksi WHERE status_transaksi = 'bayar'";
$result = $koneksi->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Transaksi - Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(to right, #112F91, #112F91);
            font-family: "Trebuchet MS", sans-serif;
            margin: 0;
            padding: 0;
        }

        h1 {
            color: #112F91;
            text-align: center;
            margin: 20px 0;
            font-size: 2.5em;
            letter-spacing: 2px;
            font-weight: bold;
        }

        .container {
            margin: 20px auto;
            width: 90%;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .btn-wrapper {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .btn-back, .btn-print {
            display: inline-block;
            padding: 12px 20px;
            font-size: 1rem;
            border-radius: 25px;
            text-decoration: none;
            text-align: center;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }

        .btn-back {
            background-color: #112F91;
            color: #fff;
        }

        .btn-back:hover {
            background-color: #0D2674;
            transform: scale(1.05);
        }

        .btn-print {
            background-color: #28a745;
            color: #fff;
        }

        .btn-print:hover {
            background-color: #218838;
            transform: scale(1.05);
        }

        table {
            width: 100%;
            margin: 20px 0;
            border-collapse: collapse;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        table th, table td {
            padding: 15px;
            text-align: left;
        }

        table thead th {
            background-color: #112F91;
            color: #fff;
            text-transform: uppercase;
            font-size: 0.9rem;
            border: 1px solid #0D2674;
        }

        table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tbody tr:hover {
            background-color: #E1E6F9;
        }

        table tbody td {
            border: 1px solid #ccc;
        }

        img {
            max-width: 100px;
            border-radius: 5px;
        }
    </style>
    <script>
        function printTable() {
            const originalContent = document.body.innerHTML;
            const printContent = document.querySelector('.container').innerHTML;
            document.body.innerHTML = printContent;
            window.print();
            document.body.innerHTML = originalContent;
        }
    </script>
</head>
<body>
    <div class="container">
        <h1>Laporan Transaksi</h1>

        <!-- Button Wrapper -->
        <div class="btn-wrapper">
            <a href="admin_dashboard.php" class="btn-back">⬅ Kembali ke Dashboard</a>
            <button class="btn-print" onclick="printTable()">🖨 Cetak Laporan</button>
        </div>

        <!-- Table -->
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>ID Transaksi</th>
                    <th>Tanggal Transaksi</th>
                    <th>Total Pembayaran</th>
                    <th>Gambar</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['id_transaksi']); ?></td>
                            <td><?= htmlspecialchars($row['tgl_transaksi']); ?></td>
                            <td>Rp <?= number_format($row['total_pembayaran'], 0, ',', '.'); ?></td>
                            <td>
                                <?php if ($row['image']): ?>
                                    <img src="uploads/<?= htmlspecialchars($row['image']); ?>" alt="Bukti">
                                <?php else: ?>
                                    <span class="text-muted">Tidak ada gambar</span>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($row['status_transaksi']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-center">Tidak ada transaksi yang sudah bayar.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
