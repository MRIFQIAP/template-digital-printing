<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Koneksi ke database
    $koneksi = new mysqli("localhost", "root", "", "digitalie");

    // Cek koneksi
    if ($koneksi-> connect_error) {
        die("Koneksi gagal: " . $koneksi-> connect_error);
    }

    // Ambil email dari form
    $email = $koneksi->real_escape_string($_POST['email']);

    // Cek apakah email ada di database
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = $koneksi->query($sql);

    if ($result->num_rows > 0) {
        // Email ditemukan
        $user = $result->fetch_assoc();

        // Buat token unik
        $token = bin2hex(random_bytes(16));
        $expiry = date("Y-m-d H:i:s", strtotime("+1 hour"));

        // Simpan token dan expiry ke database
        $update = "UPDATE users SET reset_token = '$token', token_expiry = '$expiry' WHERE email = '$email'";
        if ($koneksi->query($update) === TRUE) {
            // Kirim email reset password
            $reset_link = "http://localhost/mrifqipbo/project/update_password.php?token=" . urlencode($token);
            $subject = "Reset Password Anda";
            $message = "Klik tautan berikut untuk reset password Anda: $reset_link";
            $headers = "From: no-reply@yourwebsite.com";

            if (mail($email, $subject, $message, $headers)) {
                echo "Email reset password telah dikirim.";
            } else {
                echo "Gagal mengirim email.";
            }
        } else {
            echo "Gagal menyimpan token ke database.";
        }
    } else {
        echo "Email tidak ditemukan.";
    }

    $koneksi->close();
}
?>
