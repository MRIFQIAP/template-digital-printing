<!DOCTYPE html>
<html>
  <head>
    <title>Tambah Produk</title>
    <style type="text/css">
      /* Global style */
      * {
        font-family: "Trebuchet MS", sans-serif;
        box-sizing: border-box;
      }

      /* Header */
      h1 {
        text-transform: uppercase;
        color: #112F91; /* Warna teks utama */
        text-align: center;
        margin-top: 20px;
        font-size: 2em;
        letter-spacing: 1px;
      }

      /* Button styling */
      button, .cancel-button {
        background-color: #112F91; /* Warna utama */
        color: #ffffff; /* Warna teks */
        padding: 12px 20px;
        font-size: 16px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.3s ease;
        width: 48%; /* Lebar tombol */
        margin: 10px 1%; /* Jarak antar tombol */
        text-align: center;
      }

      button:hover {
        background-color: #0D2674; /* Warna lebih gelap saat hover */
      }

      .cancel-button {
        background-color: #112F91; /* Warna merah untuk tombol cancel */
      }

      .cancel-button:hover {
        background-color: #c9302c; /* Warna merah lebih gelap saat hover */
      }

      /* Input and select styling */
      label {
        margin-bottom: 5px;
        font-weight: bold;
        color: #112F91;
      }

      input, select {
        padding: 10px;
        width: 100%;
        background: #f8f8f8;
        border: 2px solid #ccc;
        outline-color: #112F91;
        border-radius: 5px;
        margin-bottom: 15px;
      }

      input:focus, select:focus {
        border-color: #112F91;
        background-color: #fff;
      }

      /* Form container */
      .base {
        width: 400px;
        padding: 25px;
        margin: 50px auto;
        background: #ededed; /* Warna latar form */
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
      }

      .base div {
        margin-bottom: 20px;
      }

      /* Button container */
      .button-container {
        display: flex;
        justify-content: space-between; /* Membuat tombol terpisah */
        align-items: center;
      }
    </style>
  </head>
  <body>
    <div>
      <h1>Tambah Produk</h1>
      <form method="POST" action="proses_tambah.php" enctype="multipart/form-data">
        <section class="base">
          <div>
            <label>Nama Produk</label>
            <input type="text" name="nama_produk" autofocus="" required="" />
          </div>
          <div>
            <label>Deskripsi</label>
            <input type="text" name="deskripsi" />
          </div>
          <div>
            <label for="jenis_produk">Jenis Produk</label>
            <select name="jenis_produk" id="jenis_produk" required>
            <option value="" disabled selected>Pilih Jenis Produk</option>
            <option value="banner">Banner</option>
            <option value="sticker">Sticker</option>
          </select>
          </div>
          <div>
            <label>Harga Jual</label>
            <input type="text" name="harga_jual" required="" />
          </div>
          <div>
            <label>Gambar Produk</label>
            <input type="file" name="gambar_produk" required="" />
          </div>
          <div class="button-container">
            <button type="submit">Simpan Produk</button>
            <a href="data_barang.php" class="cancel-button">Cancel</a>
          </div>
        </section>
      </form>
    </div>
  </body>
</html>
