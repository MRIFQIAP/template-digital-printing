<?php
include_once 'koneksi.php';  // Pastikan koneksi.php berisi kelas Koneksi
session_start();


// Fungsi untuk mengarahkan pengguna berdasarkan peran
function redirectUser($user) {
    $role = trim($user['role']);
    $_SESSION['id'] = $user['id'];  // Simpan ID pengguna
    $_SESSION['fname'] = $user['fname'];  // Simpan nama depan
    $_SESSION['role'] = $role;  // Simpan role
    $_SESSION['phone'] = $phone;
    switch ($role) {
        case 'admin':
            $_SESSION['admin'] = ['role' => $role];    
            header("Location: admin_dashboard.php");
            exit();
        case 'customer':
            $_SESSION['customer'] = ['role' => $role];    
            header("Location: main.php");
            exit();
        default:
            echo "<script>alert('Role tidak dikenali! Role saat ini: " . htmlspecialchars($role) . "');</script>";
            exit();
    }
}

// Cek jika metode HTTP adalah POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Query untuk mendapatkan data pengguna berdasarkan email
    $query = "SELECT * FROM users WHERE email = ?";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Cek apakah email ditemukan
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Verifikasi password
        if (password_verify($password, $user['password'])) {
            // Jika berhasil, arahkan pengguna
            redirectUser($user);
        } else {
            // Jika password salah
            echo "<script>
                    alert('Password salah!');
                    window.location.href = 'login.php';
                  </script>";
            exit();
        }
    } else {
        // Jika email tidak ditemukan
        echo "<script>
                alert('Email tidak ditemukan!');
                window.location.href = 'login.php';
              </script>";
        exit();
    }
} else {
    // Jika akses langsung ke halaman ini tanpa POST
    echo "<script>
            alert('Metode tidak diizinkan!');
            window.location.href = 'login.php';
          </script>";
    exit();
}
?>
