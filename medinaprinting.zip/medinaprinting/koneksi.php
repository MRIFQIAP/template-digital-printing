<?php
class Koneksi {
    private $host = "localhost";
    private $username = "root";
    private $password = "";
    private $database = "digitalie";

    public function getKoneksi() {
        $koneksi = new mysqli($this->host, $this->username, $this->password, $this->database);
        if ($koneksi->connect_error) {
            die("Koneksi gagal: " . $koneksi->connect_error);
        }
        return $koneksi;
    }
}

$koneksiObj = new Koneksi();
$koneksi = $koneksiObj->getKoneksi();
?>
