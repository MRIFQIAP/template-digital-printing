<?php
require_once 'koneksi.php';

class User {
    private $koneksi;

    public function __construct($db) {
        $this->koneksi = $db;
    }

    public function registrasi($fname, $lname, $email, $password, $phone, $address) {
        $password_hashed = password_hash($password, PASSWORD_BCRYPT);

        // Menggunakan prepared statement untuk mencegah SQL injection
        $query = "INSERT INTO users (fname, lname, email, password, phone, address, role) 
                  VALUES (?, ?, ?, ?, ?, ?, 'customer')";
        $stmt = $this->koneksi->prepare($query);
        $stmt->bind_param('ssssss', $fname, $lname, $email, $password_hashed, $phone, $address);

        if ($stmt->execute()) {
            // Redirect dengan pesan sukses
            echo '<script>alert("Registrasi berhasil! Silahkan Login menggunakan Email dan Password anda.");</script>';
            header('refresh:0;url=login.php');
        } else {
            // Menampilkan pesan error jika query gagal
            die("Registrasi gagal: " . $stmt->error);
        }
    }
}

// Membuat objek koneksi
$koneksiObj = new Koneksi();  // Membuat objek koneksi
$koneksi = $koneksiObj->getKoneksi();  // Mendapatkan koneksi database

// Memproses data dari form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];

    // Membuat objek User dan memanggil metode registrasi
    $user = new User($koneksi);
    $user->registrasi($fname, $lname, $email, $password, $phone, $address);
}
?>
