<?php
include_once 'koneksi.php';
session_start();

// Pastikan pengguna sudah login
if (!isset($_SESSION['id'])) {
    header('Location: login.php');
    exit;
}

$id_transaksi = isset($_GET['id']) ? $_GET['id'] : '';

// Koneksi ke database
$koneksiObj = new Koneksi();
$koneksi = $koneksiObj->getKoneksi();

// Validasi id_transaksi
if (empty($id_transaksi)) {
    die("ID transaksi tidak valid.");
}

// Ambil data transaksi
$sql = "SELECT * FROM transaksi WHERE id_transaksi = ?";
$stmt = $koneksi->prepare($sql);
$stmt->bind_param("i", $id_transaksi);
$stmt->execute();
$result = $stmt->get_result();

// Debug: Cek jumlah baris yang ditemukan
if ($result->num_rows > 0) {
    $transaksi = $result->fetch_assoc();
    // Menyimpan nilai variabel
    $tanggalTransaksi = $transaksi['tgl_transaksi'];
    $totalBayar = $transaksi['total_pembayaran'];
    $metodePembayaran = $transaksi['metode_pembayaran'];  // Pastikan kolom ini ada di database Anda
} else {
    die("Transaksi tidak ditemukan.");
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nota Transaksi</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        /* Tambahkan CSS sesuai kebutuhan */
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f7fc;
            padding: 20px;
        }

        .nota-container {
            max-width: 600px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #112F91;
        }

        .success-message {
            text-align: center;
            color: green;
            margin-bottom: 20px;
            font-size: 1.2em;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }

        .note {
            margin-top: 20px;
            padding: 15px;
            background-color: #eef4ff;
            border-left: 5px solid #112F91;
            font-size: 1.1em;
            color: #112F91;
        }

        .btn-home {
            display: block;
            margin: 20px auto;
            padding: 10px 20px;
            text-align: center;
            background-color: #112F91;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }

        .btn-home:hover {
            background-color: #0a235d;
        }
    </style>
</head>
<body>
    <div class="nota-container">
        <h1>Nota Transaksi</h1>
        <p class="success-message">Transaksi Anda berhasil!</p>

        <table>
            <tr>
                <td>Tanggal Transaksi:</td>
                <td><?= htmlspecialchars($tanggalTransaksi); ?></td>
            </tr>
            <tr>
                <td>Total Pembayaran:</td>
                <td>Rp <?= number_format($totalBayar, 0, ',', '.'); ?></td>
            </tr>
            <tr>
                <td>Metode Pembayaran:</td>
                <td><?= htmlspecialchars($metodePembayaran); ?></td>
            </tr>
        </table>

        <div class="note">
            <strong>Catatan Penting:</strong> <br>
            Harap simpan nota ini dengan baik dan tunjukkan kepada petugas saat mengambil barang. Nota ini adalah bukti resmi transaksi Anda.
        </div>

        <a href="main.php" class="btn-home">Kembali ke Beranda</a>
    </div>
</body>
</html>
