<?php
require 'koneksi.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';
require 'phpmailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $token = bin2hex(random_bytes(32)); // Token unik
    $expiry_time = date('Y-m-d H:i:s', strtotime('+1 hour')); // Kedaluwarsa 1 jam

    // Cek apakah email ada di database
    $stmt = $koneksi->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Simpan token di database
        $stmt = $koneksi->prepare("UPDATE users SET reset_token = ?, token_expiry = ? WHERE email = ?");
        $stmt->bind_param("sss", $token, $expiry_time, $email);
        if ($stmt->execute()) {
            // Kirim email reset password
            $mail = new PHPMailer(true);

            try {
                // Konfigurasi SMTP
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com'; // Host SMTP
                $mail->SMTPAuth = true;
                $mail->Username = 'mrifqiap03@gmail.com'; // Email Anda
                $mail->Password = 'vdpc ykzr jyxt ztip'; // Password aplikasi
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                // Pengaturan email
                $mail->setFrom('mrifqiap03@gmail.com', 'MRIFQI ADMIN');
                $mail->addAddress($email);
                $mail->isHTML(true);
                $mail->Subject = 'Reset Password Anda';
                $mail->Body = "Klik tautan berikut untuk mereset password Anda: <br>
                    <a href='http://localhost/mrifqipbo/project/update_password.php?token=$token'>Reset Password</a>";

                $mail->send();
                echo "<script>
                        alert('Email reset password telah dikirim! Silakan cek email Anda.');
                        window.location.href = 'lupapw.php';
                      </script>";
            } catch (Exception $e) {
                echo "<script>
                        alert('Gagal mengirim email. Error: {$mail->ErrorInfo}');
                        window.location.href = 'lupapw.php';
                      </script>";
            }
        } else {
            echo "<script>
                    alert('Gagal menyimpan token.');
                    window.location.href = 'lupapw.php';
                  </script>";
        }
    } else {
        echo "<script>
                alert('Email tidak ditemukan.');
                window.location.href = 'lupapw.php';
              </script>";
    }
}
?>
