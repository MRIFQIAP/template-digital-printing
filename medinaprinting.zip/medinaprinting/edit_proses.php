<?php
require_once 'koneksi.php';

// Membuat objek koneksi
$koneksi = new Koneksi();
$db = $koneksi->getKoneksi();

// Ambil data dari form
$id_produk = $_POST['id']; // Mengambil ID dari input hidden di edit_produk.php
$nama_produk = $_POST['nama_produk'];
$deskripsi = $_POST['deskripsi'];
$jenis_produk = $_POST['jenis_produk']; // Data dari dropdown
$harga_jual = $_POST['harga_jual'];
$gambar_produk = $_FILES['gambar_produk']['name'];

if ($gambar_produk) {
    $ekstensi_diperbolehkan = ['png', 'jpg', 'jpeg'];
    $x = explode('.', $gambar_produk);
    $ekstensi = strtolower(end($x));
    $file_tmp = $_FILES['gambar_produk']['tmp_name'];
    $nama_gambar_baru = uniqid() . '.' . $ekstensi;

    if (in_array($ekstensi, $ekstensi_diperbolehkan)) {
        // Hapus gambar lama jika ada
        $query_gambar = "SELECT gambar_produk FROM produk WHERE id = ?";
        $stmt_gambar = $db->prepare($query_gambar);
        $stmt_gambar->bind_param('i', $id_produk);
        $stmt_gambar->execute();
        $result_gambar = $stmt_gambar->get_result();

        if ($result_gambar->num_rows > 0) {
            $row = $result_gambar->fetch_assoc();
            $gambar_lama = $row['gambar_produk'];
            if ($gambar_lama && file_exists('gambar/' . $gambar_lama)) {
                unlink('gambar/' . $gambar_lama);
            }
        }

        // Upload file gambar baru
        move_uploaded_file($file_tmp, 'gambar/' . $nama_gambar_baru);

        // Update data dengan gambar baru
        $query = "UPDATE produk SET nama_produk = ?, deskripsi = ?, jenis_produk = ?, harga_jual = ?, gambar_produk = ? WHERE id = ?";
        $stmt = $db->prepare($query);
        $stmt->bind_param('sssisi', $nama_produk, $deskripsi, $jenis_produk, $harga_jual, $nama_gambar_baru, $id_produk);
    } else {
        echo "<script>alert('Ekstensi gambar harus jpg, jpeg, atau png.');window.location='edit_produk.php?id=$id_produk';</script>";
        exit;
    }
} else {
    // Update data tanpa mengubah gambar
    $query = "UPDATE produk SET nama_produk = ?, deskripsi = ?, jenis_produk = ?, harga_jual = ? WHERE id = ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param('sssii', $nama_produk, $deskripsi, $jenis_produk, $harga_jual, $id_produk);
}

// Eksekusi query
if ($stmt->execute()) {
    echo "<script>alert('Produk berhasil diupdate.');window.location='data_barang.php';</script>";
} else {
    echo "<script>alert('Gagal mengupdate produk: " . $stmt->error . "');window.location='edit_produk.php?id=$id_produk';</script>";
}
?>
