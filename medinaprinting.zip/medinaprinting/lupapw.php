<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lupa Kata Sandi</title>
    <style>
        /* Global style */
        * {
            font-family: "Trebuchet MS", sans-serif;
            box-sizing: border-box;
        }

        h1 {
            text-transform: uppercase;
            color: #112F91;
            text-align: center;
            margin-top: 20px;
        }

        .base {
            width: 400px;
            margin: 40px auto;
            padding: 20px;
            background: #ededed;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        label {
            font-weight: bold;
            color: #112F91;
        }

        input {
            padding: 10px;
            width: 100%;
            margin-top: 5px;
            border: 2px solid #ccc;
            border-radius: 5px;
        }

        button {
            background-color: #112F91;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0D2674;
        }
    </style>
</head>
<body>
    <h1>Lupa Kata Sandi</h1>
    <div class="base">
    <form action="proses_lupa_password.php" method="POST">
    <label for="email">Email Anda:</label>
    <input type="email" id="email" name="email" required>
    <button type="submit">Kirim Email</button>
    <a href="login.php" style="text-decoration: none;">
        <button type="button">Cancel</button>
    </a>
</form>
    </div>
</body>
</html>