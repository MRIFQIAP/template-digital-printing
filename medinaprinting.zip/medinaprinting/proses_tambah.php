<?php
// Memanggil file koneksi.php untuk melakukan koneksi database
require_once 'koneksi.php';

class Produk {
    private $koneksi;

    public function __construct($db) {
        $this->koneksi = $db;
    }

    public function tambahProduk($nama_produk, $deskripsi, $jenis_produk, $harga_jual, $gambar_produk) {
        if ($gambar_produk['name'] != "") {
            $ekstensi_diperbolehkan = array('png', 'jpg'); // ekstensi file gambar yang diperbolehkan
            $x = explode('.', $gambar_produk['name']); // memisahkan nama file dan ekstensi
            $ekstensi = strtolower(end($x));
            $file_tmp = $gambar_produk['tmp_name'];
            $nama_gambar_baru = $gambar_produk['name']; // nama gambar baru sesuai file asli

            if (in_array($ekstensi, $ekstensi_diperbolehkan)) {
                // Memindahkan file ke folder gambar
                if (move_uploaded_file($file_tmp, 'gambar/' . $nama_gambar_baru)) {
                    $query = "INSERT INTO produk (nama_produk, deskripsi, jenis_produk, harga_jual, gambar_produk) 
                              VALUES (?, ?, ?, ?, ?)";
                    $stmt = $this->koneksi->prepare($query);

                    // Debugging jika prepare gagal
                    if (!$stmt) {
                        die("Error prepare statement: " . $this->koneksi->error);
                    }

                    $stmt->bind_param('sssds', $nama_produk, $deskripsi, $jenis_produk, $harga_jual, $nama_gambar_baru);

                    if ($stmt->execute()) {
                        echo "<script>alert('Data berhasil ditambah.');window.location='data_barang.php';</script>";
                    } else {
                        die("Query gagal dijalankan: " . $stmt->error);
                    }
                }
            } else {
                echo "<script>alert('Ekstensi gambar yang boleh hanya jpg atau png.');window.location='tambah_produk.php';</script>";
            }
        } else {
            // Jika tidak ada gambar yang diunggah
            $query = "INSERT INTO produk (nama_produk, deskripsi, jenis produk, harga_jual, gambar_produk) 
                      VALUES (?, ?, ?, ?, NULL)";
            $stmt = $this->koneksi->prepare($query);

            // Debugging jika prepare gagal
            if (!$stmt) {
                die("Error prepare statement: " . $this->koneksi->error);
            }

            $stmt->bind_param('sssd', $nama_produk, $deskripsi, $jenis_produk, $harga_jual);

            if ($stmt->execute()) {
                echo "<script>alert('Data berhasil ditambah.');window.location='data_barang.php';</script>";
            } else {
                die("Query gagal dijalankan: " . $stmt->error);
            }
        }
    }
}

// Membuat objek koneksi
$koneksiObj = new Koneksi();  // Membuat objek koneksi
$koneksi = $koneksiObj->getKoneksi();  // Mendapatkan koneksi database

// Memproses data dari form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_produk = $_POST['nama_produk'];
    $deskripsi = $_POST['deskripsi'];
    $jenis_produk = $_POST['jenis_produk']; // Mengambil nilai dari dropdown
    $harga_jual = $_POST['harga_jual'];
    $gambar_produk = $_FILES['gambar_produk'];

    $produk = new Produk($koneksi);  // Membuat objek Produk dengan koneksi database
    $produk->tambahProduk($nama_produk, $deskripsi, $jenis_produk, $harga_jual, $gambar_produk);
}
?>
