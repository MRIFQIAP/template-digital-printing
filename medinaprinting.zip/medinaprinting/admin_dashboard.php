<?php

include 'koneksi.php'; 
session_start();

// Membuat objek koneksi
$koneksiObj = new Koneksi();
$koneksi = $koneksiObj->getKoneksi(); // Mendapatkan koneksi database

// Periksa apakah pengguna sudah login
if (isset($_SESSION['id']) && $_SESSION['id'] !== FALSE) {
    $sql = "SELECT id, fname, lname, email, password, phone, address, role 
            FROM users 
            WHERE id = ?";
    $stmt = $koneksi->prepare($sql);
    $stmt->bind_param('i', $_SESSION['id']);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $sql = "SELECT id, fname, lname, email, password, phone, address, role FROM users";
    $result = $koneksi->query($sql); // Menggunakan query langsung jika tidak ada sesi
}

// Ambil data user
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    $row = null; // Set null jika tidak ada data ditemukan
}

// Query untuk mendapatkan data pesanan
$sql2 = "SELECT confirm FROM order_list";
$test = $koneksi->query($sql2);

// Ambil data pesanan
if ($test && $test->num_rows > 0) {
    $row3 = $test->fetch_assoc();
} else {
    $row3 = null; // Set null jika tidak ada data pesanan ditemukan
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/font/font-face.css">
    <link rel="stylesheet" href="bootstrap_custom.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <title>Admin | Medina Printing</title>
</head>

<body>
        
    <!-- Navbar -->
    <nav class="navbar navbar-expand-md navbar-light px-6 font-regular" id="navbar">
        <div class="container-fluid">
            <a class="navbar-brand" href="main.php">
                <img src="assets/logo.svg" alt="" width="200">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <!-- navbar menu -->
            <div class="collapse navbar-collapse" id="navbarsExample04">
                <ul class="navbar-nav mx-auto mb-2 mb-md-0">
                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] == "admin") {
                    ?>
                        <li class="nav-item mx-2">
                            <a class="nav-link" aria-current="page" href="#">Beranda</a>
                        </li>
                        <li class="nav-item mx-2">
                            <a class="nav-link" aria-current="page" href="data_barang.php">Tambah Produk</a>
                        </li>
                        <li class="nav-item mx-2">
                            <a class="nav-link" href="laporan_transaksi.php">Laporan Transaksi</a>
                        </li>
                        <li class="nav-item mx-2">
                            <a class="nav-link" href="#jump-contact">Kontak</a>
                        </li>
                        <li class="nav-item mx-2">
                            <a class="nav-link" href="#jump-aboutus">Tentang Kami</a>
                        </li>
                    <?php }  ?>

                </ul>
                </li>
                </ul>
                
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown font-semibold text-black" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            ID
                        </a>
                    </li>
                    <li class="nav-item mx-2">
                        <a class="nav-link" id="search-button" href="#searchForm" data-target="#searchForm" role="button" aria-expanded="false" data-bs-toggle="collapse">
                            <i class="fa fa-search"></i>
                            <i class="fa fa-close text-danger"></i>
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <div class="input-group collapse" id="searchForm">
                            <input type="text" class="form-control rounded-pill" placeholder="Search" aria-label="Search" aria-describedby="basic-addon2">
                            <div class="input-group-append collapse" id="cari">
                                <button class="btn btn-outline-secondary" id="cari" type="button"><i class="fa fa-search" aria-hidden="true" aria-controls="searchForm"></i></button>
                            </div>
                        </div>
                    </li>
                    
                    <li class="nav-item dropdown mx-2">
                        <a class="nav-link dropdown font-semibold text-black" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php if (isset($_SESSION['role']) && $_SESSION['role']) {
                            ?>
                                <?php
                                echo "<button class='btn btn-sm font-medium button-theme text-light rounded-pill px-3' type='button'>Hello, " . $row['fname'] . "!" . "</button>";
                                ?>
                            <?php } else { ?>
                                <button class="btn btn-sm font-medium button-theme text-light rounded-pill px-3" type="button">Hello, Guest!</button>
                            <?php }  ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-light" aria-labelledby="navbarDarkDropdownMenuLink">
                            <?php if (isset($_SESSION['role']) && $_SESSION['role']) {
                           
                               
                                
                                echo "<li><a class='dropdown-item' href='quotation.php'>Quotation</a></li><li><a class='dropdown-item' href='logout.php'>Logout</a></li>";
                                
                               
                                ?>
                            <?php } else { ?>
                                <li><a class="dropdown-item" href="login.php">Login</a></li>
                                <li><a class="dropdown-item" href="register.php">Register</a></li>
                            <?php }  ?>
                        </ul>
                    </li>
                    
                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] == "customer") {
                    ?>
                        <?php
                        echo "<li class='nav-item'>
                            <a class='nav-link position-relative btn btn-sm font-medium button-theme2 rounded-3' type='button' href='cart.php'>Cart <i class='fa fa-shopping-cart' aria-hidden='true'></i></a></li>";
                        ?>
                    <?php } else { ?>
                    <?php }  ?>
                    
                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] == "admin") {
                    ?>
                        <?php
                        echo "<li class='nav-item mx-2'>
                        <a class='nav-link position-relative btn btn-sm font-medium button-theme2 rounded-3' type='button' href='order_list.php'>Order <i class='fa fa-list-alt' aria-hidden='true'></i><span class='position-absolute top-0 start-100 translate-middle p-2 bg-danger border border-light rounded-circle'><span class='visually-hidden'>New alerts</span></a></li>";
                        ?>
                    <?php } else { ?>
                    <?php }  ?>
            </div>
        </div>
    </nav>
    
    <section id="landing" style="height:30rem">
        <div class="container my-5" id="wrapper1">
            <div class="row">
                <div class="col">
                    <div class="welcoming mt-6">
                        <h3 class="font-semibold">
                         Temukan segala kebutuhan Anda dalam <span style="color:#112f91">digital printing</span>
                         di tempat kami,<br>
                            <h2 style="color: #112F91; font-weight: bold;">Medina Printing</h2>
                        </h3>
                        <div class="bungkusbutton mt-5 font-regular">
                            <a href="#jump-ourstore">
                                <button type="button" class="btn btn-primary btn-block px- button-theme rounded-3" id="locate-nearby-button">Toko Terdekat</button></a>
                            <a href="products.php">
                                <button type="button" class="btn btn-light btn-block px-4 m-lg-2 button-theme2 rounded-3" id="check-product-button" href="products.php">Produk</button></a>
                        </div>
                    </div>
                </div>
                <div class="col px-2">
                    <img src="assets/gambarhome.svg" width="100%" alt="" id="figure1" />
                </div>
            </div>
        </div>
    </section>
    <!-- End Landing Page -->

    <!-- Our Best Selling Services -->
    <section id="best-selling-services">
        <div class="background-arrow">
            <div class="container my-5 py-5">
                <div class="row text-center text-center">
                    <div class="col rounded w-100">
                        <h2 class="mb-3 font-semibold">Layanan Terlaris Kami</h2>
                        <p class="mb-5 font-regular mt-4">Di <span style="color:#112f91">Medina Printing</span>,  kami sangat menjaga kualitas dalam melayani pelanggan, <br>
                        layanan terbaik kami berdasarkan peringkat mereka.</p>
                    </div>
                </div>
                <div class="container d-flex justify-content-center" id="wrapper2-konten">
                    <div class="row text-center" data-aos="zoom-out-up">
                        <div class="col">
                            <div class="card mx-2" id="wrapper2-card">
                                <img src="assets/sticker.svg" class="card-img-top py-4" width="150px" height="150px" />
                                <div class="card-body">
                                    <h3 class="font-semibold">Sticker</h3>
                                    <p class="card-text font-regular">Kami memberikan pelayanan terbaik demi kepuasan pelanggan.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="card mx-2" id="wrapper2-card">
                                <img src="assets/printing.svg" class="card-img-top" width="150px" height="150px" />
                                <div class="card-body">
                                    <h3 class="font-semibold">Printing</h3>
                                    <p class="card-text font-regular">Teknologi canggih dengan produksi terbaik dan tercepat</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="card mx-2" id="wrapper2-card">
                                <img src="assets/card.svg" class="card-img-top" width="150px" height="150px" />
                                <div class="card-body">
                                    <h3 class="font-semibold">Card</h3>
                                    <p class="card-text font-regular">Kami selalu menjaga bahan dan teknologi kami untuk hasil yang lebih baik</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <section id="jump-ourproduct">
        <div class="container my-5 py-5">
            <div class="row">
                <div class="col-6">
                    <img src="assets/ourproducts.svg" width="80%">
                </div>
                <div class="col-6" data-aos="zoom-out-left">
                    <h2 class="font-semibold mb-4">Produk Kami</h2>
                    <p class="font-regular">
                    Dengan pengalaman luas dalam beragam desain, material berkualitas tinggi, dan dukungan teknologi modern, kami menghadirkan kualitas terbaik di setiap produk untuk dinikmati oleh pelanggan.
                    </p>
                    <div class="container py-4">
                        <div class="row">
                            <div class="col">
                                <div class="card" style="width: 80%">
                                    <a href="products.php" class="text-decoration-none ">
                                    <div class="text-center">
                                        <img src="assets/koran.svg" class="card-img-top ps-2 py-2" style="width: 50px;">
                                        <div class="card-body d-flex flex-column align-items-center">
                                        <h5 class="card-title font-semibold blue-theme blue-hover" style="color:#1B7FBD;">Produk</h5>
                                        <p class="card-text font-regular text-black text-center">Cek produk terbaru kami disini!</p>
                                        </div>
                                        </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="jump-ourstore"></div>
        </div>
        
        <section id="ourstore">
            <div class="container my-5 py-5">
                <div class="row">
                    <div class="col-6" data-aos="zoom-out-right">
                        <h2 class="font-semibold py-4">Toko Kami</h2>
                        <p class="font-regular">
                            Terletak di lokasi paling strategis di kota Subang, sehingga mudah untuk dijangkau oleh pelanggan dari berbagai wilayah.
                        </p>

                        <div class="font-regular">
                            <a href="https://maps.app.goo.gl/6HvGGwmFFTDNYXkx7" target="_blank" rel="noopener noreferrer">
                            <button type="button" class="btn btn-primary btn-sm px-4 py-2 font-semibold me-2 button-theme rounded-3">
                            Lokasi Google Maps <img src="assets/googlemaps.svg"></button>
                            </a>
                        </div>
                    </div>
                    <div class="col-6" >
                        <img src="assets/ourstores.svg" width="100%" height="300" data-aos="zoom-out-left">
                    </div>
                </div>
                <div id="jump-contact"></div>
            </div>
        </section>

        
        <section id="contact">
            <div class="container my-5 py-5 px-5 d-flex justify-content-around">
                <div class="row">
                    <div class="col-6 py-5" data-aos="fade-right">
                        <h3 class="font-bold blue-theme">Medina Printing</h3>
                        <h4 class="font-regular">Your Digital Creations</h4>
                    </div>
                    <div class="col-6" data-aos="fade-left">
                        <h2 class="font-semibold">Contact</h2>
                        <a class="nav-link text-start text-black font-semibold" href="#"><img src="assets/whatsapp.svg">
                            +62 877 8252 2774</a>
                        <a class="nav-link font-semibold text-black text-start" href="#"><img src="assets/instagram.svg"> @medinaprinting</a>
                    </div>
                </div>
            </div>
        </section>

        <section id="jump-aboutus">
    <!-- about us -->
    <div class="container my-5 py-5 mt-6" data-aos="fade-up">
        <div class="row text-center">
            <div class="col">
                <h2 class="font-semibold">Tentang Kami</h2>
                <h3 class="font-bold blue-theme">Medina Printing</h3>
            </div>
        </div>
        <div class="row mt-5 mx-5">
            <div class="col-6 d-flex justify-content-center">
                <img src="assets/vanneslie.svg" class="" width="200">
            </div>
            <div class="col-6" data-aos="fade-up">
    <h2>Selamat Datang di Medina Printing</h2>
    <p style="text-align: justify;">Layanan Digital Printing dengan Kualitas Terbaik dan Harga Bersaing</p>

    <h2>Tentang Medina Printing</h2>
    <p style="text-align: justify;"><strong>Medina Printing</strong> adalah perusahaan yang menyediakan layanan digital printing dan percetakan dengan fokus pada kualitas, kecepatan, dan harga yang kompetitif. Sejak didirikan pada tahun 2019, kami telah melayani berbagai kebutuhan cetak untuk individu dan bisnis, termasuk percetakan brosur, kartu nama, dan banner. Kami berkomitmen untuk memberikan hasil terbaik dengan menggunakan teknologi cetak terbaru serta memberikan pelayanan yang memuaskan bagi pelanggan kami.</p>

    <h3>Visi Kami</h3>
    <p style="text-align: justify;">Menjadi penyedia layanan digital printing terdepan yang dikenal akan inovasi, kualitas tinggi, dan pelayanan yang memuaskan di seluruh Indonesia.</p>

    <h3>Misi Kami</h3>
    <ul>
        <li style="text-align: justify;">Menyediakan solusi percetakan yang berkualitas dan terjangkau bagi pelanggan di berbagai sektor.</li>
        <li style="text-align: justify;">Mengutamakan kepuasan pelanggan dengan layanan cepat, tepat waktu, dan hasil cetak yang memuaskan.</li>
        <li style="text-align: justify;">Memanfaatkan teknologi cetak terbaru untuk menghasilkan produk dengan presisi tinggi dan kualitas terbaik.</li>
        <li style="text-align: justify;">Meningkatkan kepercayaan dan loyalitas pelanggan melalui hubungan jangka panjang yang saling menguntungkan.</li>
    </ul>
</div>


            </div>
        </div>
    </div>
</section>

                </div>
                <div class="row mt-5">
    <div class="col-8 mx-auto text-center" data-aos="fade-up">
        <p class="font-regular fs-5 my-4" style="text-align: justify;">
            Didirikan sejak tahun 2019, Medina Printing telah beroperasi selama hampir lima tahun. Dengan keahlian dalam bidang percetakan yang didukung oleh mesin-mesin cetak canggih, kami menghasilkan cetakan berkualitas terbaik untuk setiap kebutuhan pelanggan.
        </p>

        <p style="font-family: Poppins; font-size: 17pt; margin-top: 30px; font-weight: bold;">Customers satisfaction is our top priority.</p>
        <p style="font-family: Poppins; font-size: 17pt; font-style: italic; margin-bottom: 20px;">“Beyond Your Expectations”</p>
    </div>
</div>

            </div>
        </section>
        
        <footer>
            <img src="assets/footer.svg" alt="" width="100%">
            <nav class="navbar bottom navbar-expand-sm navbar-dark blue-background px-6 pb-3">
                <div class="container-fluid">
                    <a class="navbar-brand" href="#"><img src="assets/logo_footer.svg" width="60%" alt=""></a>
                    <div class="text-light font-regular text-center mt-3">© Copyright 2024. Design of Medina Printing (Kelompok 1)</div>

                    <ul class="navbar-nav">
                        <li class="nav-item dropup mx-2">
                            <a class="nav-link dropup font-semibold text-light" href="#" id="navbarDarkDropdownMenuLinkBottom" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                ID
                            </a>
                        </li>
                        <li class="nav-item mx-2">
                            <a class="nav-link" id="search-button" href="#searchForm" data-target="#searchForm" role="button" aria-expanded="false" data-bs-toggle="collapse">
                                <i class="fa fa-search text-light"></i>
                                <i class="fa fa-close text-light"></i>
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <div class="input-group collapse" id="searchForm">
                                <input type="text" class="form-control rounded-pill" placeholder="Search" aria-label="Search" aria-describedby="basic-addon2">
                                <div class="input-group-append collapse" id="cari">
                                    <button class="btn btn-outline-secondary" id="cari" type="button"><i class="fa fa-search" aria-hidden="true" aria-controls="searchForm"></i></button>
                                </div>
                            </div>
                        </li>
                    </ul>

                </div>
            </nav>
        </footer>

        <button onclick="topFunction()" id="myBtn" title="Go to top">
            <i class="fa fa-angle-double-up fs-1" aria-hidden="true"></i>
        </button>

        <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
        <script>
            AOS.init();
        </script>
        <script src="script.js"></script>
</body>

</html>