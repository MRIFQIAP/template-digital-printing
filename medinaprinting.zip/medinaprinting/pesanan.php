<?php

include 'koneksi.php';
session_start();
$koneksiObj = new Koneksi();
$koneksi = $koneksiObj->getKoneksi();

if (!isset($_SESSION['id'])) {
    header('Location: login.php');
    exit();
}

$sql = "SELECT id, fname, lname, email, password, phone, address, role FROM users WHERE id = ?";
$stmt = $koneksi->prepare($sql);
$stmt->bind_param("i", $_SESSION['id']);
$stmt->execute();
$result2 = $stmt->get_result();
$row2 = $result2->fetch_assoc();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$query = "SELECT * FROM produk WHERE id = ?";
$stmt = $koneksi->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if (!$row) {
    echo "Product not found.";
    exit();
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/font/font-face.css">
    <link rel="stylesheet" href="bootstrap_custom.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <title>Pesan | Medina Printing</title>
    <style>
           form textarea, form input {
        margin-bottom: 1rem; /* Memberikan jarak antar elemen */
    }

    .form-label {
        font-weight: bold; /* Memberikan penekanan pada label */
    }

    .d-flex {
        gap: 10px; /* Jarak antar tombol */
    } 
    </style>
</head>
<body>
<!-- Navbar -->
<nav class="navbar navbar-expand-md navbar-light px-6 font-regular" id="navbar">
    <div class="container-fluid">
        <a class="navbar-brand" href="main.php">
            <img src="assets/logo.svg" alt="" width="200">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- navbar menu -->
        <div class="collapse navbar-collapse" id="navbarsExample04">
                <ul class="navbar-nav mx-auto mb-2 mb-md-0">
                    <?php { ?>
                    <li class="nav-item mx-2">
                    <a class="nav-link" aria-current="page" href="main.php">Beranda</a>
                    </li>
                    <li class="nav-item mx-2">
                    <a class="nav-link" href="#jump-ourproduct">Produk</a>
                    </li>
                    <li class="nav-item mx-2">
                    <a class="nav-link" href="main.php#jump-ourstore">Toko</a>
                    </li>
                    <li class="nav-item mx-2">
                    <a class="nav-link" href="main.php#jump-contact">Kontak</a>
                    </li>
                    <li class="nav-item mx-2">
                    <a class="nav-link" href="main.php#jump-aboutus">Tentang Kami</a>
                    </li>
                    <?php } ?>
                </ul>
            <!-- language and search button -->
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown font-semibold text-black" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        ID
                    </a>
                    <ul class="dropdown-menu dropdown-menu-light" aria-labelledby="navbarDarkDropdownMenuLink">
                        <li><a class="dropdown-item" href="#" onclick="id_language();">ID</a></li>
                    </ul>
                </li>
                <li class="nav-item mx-2">
                    <a class="nav-link" id="search-button" href="#searchForm" data-target="#searchForm" role="button" aria-expanded="false" data-bs-toggle="collapse">
                        <i class="fa fa-search"></i>
                        <i class="fa fa-close text-danger"></i>
                    </a>
                </li>
                <li class="nav-item dropdown">
                    <div class="input-group collapse" id="searchForm">
                        <input type="text" class="form-control rounded-pill" placeholder="Search" aria-label="Search" aria-describedby="basic-addon2">
                        <div class="input-group-append collapse" id="cari">
                            <button class="btn btn-outline-secondary" id="cari" type="button"><i class="fa fa-search" aria-hidden="true" aria-controls="searchForm"></i></button>
                        </div>
                    </div>
                </li>
                <!-- login/register -->
                <li class="nav-item dropdown mx-2">
                    <a class="nav-link dropdown font-semibold text-black" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php if (isset($_SESSION['role']) && $_SESSION['role']) : ?>
                            <button class='btn btn-sm font-medium button-theme text-light rounded-pill px-3' type='button'>Hello, <?php echo htmlspecialchars($row2['fname']); ?>!</button>
                        <?php else : ?>
                            <button class="btn btn-sm font-medium button-theme text-light rounded-pill px-3" type="button">Hello, Guest!</button>
                        <?php endif; ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-light" aria-labelledby="navbarDarkDropdownMenuLink">
                        <?php if (isset($_SESSION['role']) && $_SESSION['role']) : ?>
                            <li><a class='dropdown-item' href='quotation.php'>Quotation</a></li>
                            <li><a class='dropdown-item' href='logout.php'>Logout</a></li>
                        <?php else : ?>
                            <li><a class="dropdown-item" href="login.php">Login</a></li>
                            <li><a class="dropdown-item" href="register.php">Register</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <!-- Shopping Cart -->
                <?php if (isset($_SESSION['role']) && $_SESSION['role'] == "customer") : ?>
                    <li class='nav-item'>
                        <a class='nav-link position-relative btn btn-sm font-medium button-theme2 rounded-3' type='button' href='keranjang.php'>Keranjang <i class='fa fa-shopping-cart' aria-hidden='true'></i></a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<!-- endnavbar -->

<div class="container">
    <!--Checkout-->
    <section id="ConfirmOrder">
        <div class="container" id="atasconfirm">
            <div class="row mt-3">
                <div class="col">
                    <h1 class="text-end font-semibold">Pesanan </h1>
                </div>
            </div>
        </div>
    </section>
    <!--End Checkout-->

    <!-- Section Checkout -->
<section id="formCheckout">
    <div class="row mt-3">
        <!-- Kolom Gambar Produk -->
        <div class="col-lg-4">
            <h2 class="text-start ms-3 font-semibold pb-3"><?php echo htmlspecialchars($row['nama_produk']); ?></h2>
            <img src="gambar/<?php echo htmlspecialchars($row['gambar_produk']); ?>" class="py-3 px-3 mt-2 d-block border rounded-3" alt="" width="90%">
        </div>
        <!-- Kolom Form -->
        <div class="col-lg-8">
        <form action="proses_pesanan.php" method="POST" enctype="multipart/form-data">
    <!-- Form Input Lainnya -->
    <div class="mb-3">
        <label for="customerName" class="form-label">Nama Customer</label>
        <input type="text" class="form-control" id="customerName" name="customerName" 
            value="<?php echo htmlspecialchars($row2['fname'] . ' ' . $row2['lname']); ?>" readonly>
    </div>
    
    <!-- Alamat dan No HP -->
    <div class="row mb-3">
        <div class="col-md-6">
            <label for="customerAddress" class="form-label">Alamat</label>
            <input type="text" class="form-control" id="customerAddress" name="customerAddress" 
                value="<?php echo htmlspecialchars($row2['address']); ?>" readonly>
        </div>
        <div class="col-md-6">
            <label for="customerPhone" class="form-label">No HP</label>
            <input type="text" class="form-control" id="customerPhone" name="customerPhone" 
                value="<?php echo htmlspecialchars($row2['phone']); ?>" readonly>
        </div>
    </div>
    
    <!-- Jumlah (Quantity) -->
    <div class="mb-3">
        <label for="productQuantity" class="form-label">Jumlah (Quantity)</label>
        <input type="number" class="form-control" id="productQuantity" name="quantity" value="1" min="1" required>
    </div>

    <!-- Upload Design -->
    <div class="mb-3">
        <label for="uploadImage" class="form-label">Upload Design</label>
        <input type="file" class="form-control" id="uploadImage" name="uploadImage" accept="image/*" required>
    </div>

    <!-- Harga Satuan (Hidden) -->
    <input type="hidden" id="unitPrice" value="<?php echo $row['harga_jual']; ?>">

    <!-- Total Harga -->
    <div class="mb-3">
        <label for="totalPrice" class="form-label">Total Harga</label>
        <input type="text" class="form-control" id="totalPrice" name="totalPrice" readonly>
    </div>

    <!-- Input Hidden untuk ID Produk -->
    <input type="hidden" name="productId" value="<?php echo $row['id']; ?>">

    <!-- Tombol Submit dan Cancel -->
    <div class=".d-flex justify-content-between">
        <button type="submit" class="btn btn-primary">Konfirmasi Pesanan</button>
        <a href="products.php" class="btn btn-secondary">Cancel</a>
    </div>
</form>

        </div>


        <script>
    function confirmOrder() {
        // Menampilkan notifikasi bahwa pesanan berhasil masuk ke keranjang
        alert("Pesanan berhasil masuk ke keranjang!");

        // Mengarahkan pengguna kembali ke halaman products.php
        window.location.href = "products.php";

        // Membiarkan proses form tetap berjalan agar data tersimpan di keranjang
        return true;
    }
</script>
<!-- Script untuk Menghitung Total Harga -->
<script>
    // Fungsi untuk Menghitung Total Harga
    function updateTotalPrice() {
        const quantity = parseInt(document.getElementById('productQuantity').value);
        const unitPrice = parseInt(document.getElementById('unitPrice').value);
        const totalPrice = isNaN(quantity) || isNaN(unitPrice) ? 0 : quantity * unitPrice;

        // Format Total Harga ke Format Rupiah
        document.getElementById('totalPrice').value = 'Rp ' + totalPrice.toLocaleString('id-ID');
    }

    // Event Listener untuk Input Quantity
    document.getElementById('productQuantity').addEventListener('input', updateTotalPrice);

    // Hitung Total Harga saat Halaman Dimuat
    updateTotalPrice();
</script>
    </div>
</section>


</div>

<script src="script.js"></script>
</body>
</html>