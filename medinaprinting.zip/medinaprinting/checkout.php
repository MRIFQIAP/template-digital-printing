<?php
include_once 'koneksi.php';
session_start();

// Pastikan pengguna sudah login
if (!isset($_SESSION['id'])) {
    header('Location: login.php');
    exit;
}

// Koneksi ke database
$koneksiObj = new Koneksi();
$koneksi = $koneksiObj->getKoneksi();

// Ambil data pesanan berdasarkan user_id
$user_id = $_SESSION['id'];
$sql = "SELECT keranjang.*, produk.nama_produk, produk.harga_jual FROM keranjang
        INNER JOIN produk ON keranjang.id_produk = produk.id
        WHERE keranjang.user_id = ?";
$stmt = $koneksi->prepare($sql);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Variabel untuk menghitung total bayar
$totalBayar = 0;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        /* Global Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f7fc;
            color: #333;
            padding: 20px;
        }

        h1 {
            text-align: center;
            font-size: 2.5em;
            color: #112F91;
            margin-bottom: 20px;
        }

        .checkout-container {
            width: 90%;
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th, table td {
            text-align: left;
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }

        table th {
            background-color: #112F91;
            color: #fff;
        }

        table td {
            background-color: #f9f9f9;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #112F91;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            font-size: 1em;
            border: 1px solid #ddd;
            border-radius: 5px;
            background: #f9f9f9;
        }

        .btn-submit {
            display: block;
            width: 100%;
            padding: 12px;
            text-align: center;
            background-color: #112F91;
            color: #fff;
            font-size: 1.1em;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s ease;
        }

        .btn-submit:hover {
            background-color: #0a235d;
        }

        .payment-info {
            display: none;
            margin-top: 10px;
            background-color: #eef4ff;
            padding: 10px;
            border-radius: 5px;
            color: #112F91;
        }

        .empty-cart {
            text-align: center;
            font-size: 1.2em;
            color: #555;
            margin: 20px 0;
        }

        .center-buttons a {
            text-decoration: none;
            display: inline-block;
            margin: 10px;
            padding: 10px 20px;
            background-color: #112F91;
            color: #fff;
            font-weight: bold;
            border-radius: 5px;
            transition: 0.3s ease;
        }

        .center-buttons a:hover {
            background-color: #0a235d;
        }

        
        .btn-center-split {
            display: flex;
            justify-content: space-between;
            gap: 10px;
            margin-top: 15px;
        }

        .btn-split {
            flex: 1;
        }

    </style>
</head>
<body>

    <h1>Checkout</h1>

    <div class="checkout-container">
        <?php if ($result && $result->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Produk</th>
                        <th>Quantity</th>
                        <th>Harga</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td><?= htmlspecialchars($row['nama_produk']); ?></td>
                        <td><?= htmlspecialchars($row['quantity']); ?></td>
                        <td>Rp <?= number_format($row['harga_jual'], 0, ',', '.'); ?></td>
                        <td>Rp <?= number_format($row['total_price'], 0, ',', '.'); ?></td>
                    </tr>
                    <?php
                    $totalBayar += $row['total_price'];
                    endwhile;
                    ?>
                </tbody>
            </table>

            <form action="proses_transaksi.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="user_id" value="<?= $_SESSION['id']; ?>">
                <input type="hidden" name="totalBayar" value="<?= $totalBayar; ?>">

                <div class="form-group">
                    <label>Tanggal Transaksi:</label>
                    <input type="text" value="<?= date('Y-m-d H:i:s'); ?>" readonly>
                </div>

                <div class="form-group">
                    <label>Total Pembayaran:</label>
                    <input type="text" value="Rp <?= number_format($totalBayar, 0, ',', '.'); ?>" readonly>
                </div>

                <div class="form-group">
                    <label>Metode Pembayaran:</label>
                    <select name="metode_pembayaran" id="metode_pembayaran" onchange="togglePaymentInfo()" required>
                        <option value="">-- Pilih --</option>
                        <option value="bank bri">Bank BRI</option>
                        <option value="dana">Dana</option>
                    </select>
                </div>

                <div id="payment_info_bri" class="payment-info">
                    Nomor Rekening BRI: 123-456-7890
                </div>

                <div id="payment_info_dana" class="payment-info">
                    Nomor Dana: 0812-3456-7890
                </div>

                <div class="form-group">
                    <label>Unggah Bukti Transfer:</label>
                    <input type="file" name="image">
                </div>

                <button type="submit" class="btn-submit">Konfirmasi Pembayaran</button>
            </form>
        <?php else: ?>
            <p class="empty-cart">Keranjang Anda kosong. Tambahkan produk untuk melanjutkan.</p>
        <?php endif; ?>
    </div>

        <!-- Tombol Kembali ke Keranjang dan Beranda -->
            <div class="btn-center-split">
                <a href="keranjang.php" class="btn-split">Kembali ke Keranjang</a>
                <a href="main.php" class="btn-split">Kembali ke Beranda</a>
            </div>

    <script>
        function togglePaymentInfo() {
            const metode = document.getElementById('metode_pembayaran').value;
            document.getElementById('payment_info_bri').style.display = metode === 'bank bri' ? 'block' : 'none';
            document.getElementById('payment_info_dana').style.display = metode === 'dana' ? 'block' : 'none';
        }
    </script>

</body>
</html>


