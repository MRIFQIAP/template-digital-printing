<?php
if (!empty($_SESSION)) {
} else {
    session_start();
}

require_once 'koneksi.php';

// Cek apakah admin sudah login
if (empty($_SESSION['admin'])) {
    echo '<script>alert("Required Login Authorization!");window.location="login.php"</script>';
    exit;
}

// Membuat objek koneksi
$koneksi = new Koneksi();
$db = $koneksi->getKoneksi();

?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style type="text/css">
    /* Global style */
    * {
        font-family: "Trebuchet MS", sans-serif;
        box-sizing: border-box;
    }

    /* Header */
    h1 {
        text-transform: uppercase;
        color: #112F91; /* Warna teks utama */
        text-align: center;
        margin-top: 20px;
        font-size: 2em;
        letter-spacing: 1px;
    }

    /* Table styling */
    table {
        border: 1px solid #112F91;
        border-collapse: collapse;
        width: 80%;
        margin: 20px auto;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    table thead th {
        background-color: #112F91; /* Warna utama */
        border: 1px solid #0D2674; /* Warna sedikit lebih gelap untuk pembatas */
        color: #ffffff; /* Warna teks yang kontras dengan latar belakang */
        padding: 12px;
        text-align: left;
        font-weight: bold;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    table tbody tr:nth-child(even) {
        background-color: #E1E6F9; /* Warna lebih terang untuk baris genap */
    }

    table tbody tr:hover {
        background-color: #B3BCF2; /* Warna lebih gelap saat hover */
        cursor: pointer;
    }

    table tbody td {
        border: 1px solid #112F91;
        color: #112F91;
        padding: 12px;
        text-align: left;
        transition: all 0.3s ease;
    }

    /* Link styling */
    a {
        background-color: #112F91; /* Warna utama */
        color: #ffffff; /* Warna teks yang kontras */
        padding: 10px 15px;
        text-decoration: none;
        font-size: 14px;
        border-radius: 5px;
        transition: background-color 0.3s;
        display: inline-block;
        text-align: center;
    }

    a:hover {
        background-color: #0D2674; /* Warna lebih gelap untuk efek hover */
    }
</style>


</head>
<body>
    <center><h1>Data Produk</h1></center>
    <center>
        <a href="admin_dashboard.php">Beranda</a>
        <a href="tambah_produk.php">+ &nbsp; Tambah Produk</a>
    </center>
    <br/>
    <table>
      <thead>
        <tr>
          <th>No</th>
          <th>Produk</th>
          <th>Deskripsi</th>
          <th>Jenis Produk</th>
          <th>Harga Jual</th>
          <th>Gambar</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
        // Query untuk mendapatkan data produk
        $query = "SELECT * FROM produk ORDER BY id ASC";
        $stmt = $db->prepare($query);
        $stmt->execute();
        $result = $stmt->get_result();

        // Periksa jika ada error saat menjalankan query
        if ($result === false) {
            die("Query Error: " . $db->error);
        }

        // Buat perulangan untuk menampilkan data
        $no = 1; // Variabel untuk nomor urut
        while ($row = $result->fetch_assoc()) {
        ?>
        <tr>
            <td><?php echo $no; ?></td>
            <td><?php echo htmlspecialchars($row['nama_produk']); ?></td>
            <td><?php echo htmlspecialchars(substr($row['deskripsi'], 0, 20)); ?>...</td>
            <td><?php echo htmlspecialchars(substr($row['jenis_produk'], 0, 20)); ?></td>
            <td>Rp <?php echo number_format($row['harga_jual'], 0, ',', '.'); ?></td>
            <td style="text-align: center;">
                <img src="gambar/<?php echo htmlspecialchars($row['gambar_produk']); ?>" style="width: 120px;">
            </td>
            <td>
                <a href="edit_produk.php?id=<?php echo $row['id']; ?>">Edit</a> |
                <a href="proses_hapus.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Anda yakin akan menghapus data ini?')">Hapus</a>
            </td>
        </tr>
        <?php
            $no++;
        }
        ?>
      </tbody>
    </table>
</body>
</html>
</html>
