<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['id'])) {
    die("Error: Anda harus login terlebih dahulu.");
}

// Ambil data dari form
$customerName = $_POST['customerName'] ?? '';
$customerAddress = $_POST['customerAddress'] ?? '';
$customerPhone = $_POST['customerPhone'] ?? '';
$productQuantity = (int)($_POST['quantity'] ?? 0);
$totalPrice = str_replace(['Rp', '.', ' '], '', $_POST['totalPrice']); // Hilangkan format Rp
$uploadedImage = $_FILES['uploadImage'];
$userId = $_SESSION['id'] ?? 0; // Ambil user_id dari session
$productId = (int)($_POST['productId'] ?? 0); // Ambil productId dari form

// Validasi data
if (empty($customerName) || empty($customerAddress) || empty($customerPhone) || $productQuantity <= 0 || empty($totalPrice) || $productId <= 0) {
    die("Error: Data tidak lengkap.");
}

// Cek apakah produk dengan productId ada di tabel produk
$queryCheckProduk = "SELECT COUNT(*) FROM produk WHERE id = ?";
$stmtCheck = $koneksi->prepare($queryCheckProduk);
if (!$stmtCheck) {
    die("Error preparing query: " . $koneksi->error);
}
$stmtCheck->bind_param("i", $productId);
$stmtCheck->execute();
$stmtCheck->bind_result($countProduk);
$stmtCheck->fetch();

// Pastikan membersihkan hasil query
$stmtCheck->free_result();

if ($countProduk == 0) {
    die("Error: Produk tidak ditemukan.");
}

// Proses upload file
$targetDir = "uploads/";
if (!is_dir($targetDir)) {
    mkdir($targetDir, 0777, true);
}
$uniqueFileName = uniqid() . "_" . basename($uploadedImage['name']);
$targetFile = $targetDir . $uniqueFileName;

if (!move_uploaded_file($uploadedImage['tmp_name'], $targetFile)) {
    die("Error: Gagal mengunggah file.");
}

// Simpan data ke tabel keranjang menggunakan prepared statement
$query = "INSERT INTO keranjang (user_id, customer_name, address, phone, quantity, total_price, image, id_produk) 
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $koneksi->prepare($query);
if (!$stmt) {
    die("Error preparing query: " . $koneksi->error);
}

$stmt->bind_param("isssidsi", $userId, $customerName, $customerAddress, $customerPhone, $productQuantity, $totalPrice, $targetFile, $productId);

if ($stmt->execute()) {
    echo "<script>
        alert('Pesanan berhasil masuk ke keranjang!');
        window.location.href = 'products.php';
    </script>";
} else {
    echo "Error: " . $stmt->error;
}
?>
