<?php
if (isset($_GET['token'])) {
    $token = $_GET['token'];

    $koneksi = new mysqli("localhost", "root", "", "digitalie");

    if ($koneksi->connect_error) {
        die("Koneksi gagal: " . $koneksi->connect_error);
    }

    $sql = "SELECT * FROM users WHERE reset_token = ? AND token_expiry > NOW()";
    $stmt = $koneksi->prepare($sql);
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
    } else {
        echo "Token tidak valid atau sudah kadaluarsa.";
        exit();
    }
} else {
    echo "Token tidak ditemukan.";
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
</head>
<body>
    <h1>Reset Kata Sandi</h1>
    <form action="reset_password.php?token=<?php echo htmlspecialchars($token); ?>" method="POST">
        <label for="new_password">Password Baru:</label>
        <input type="password" id="new_password" name="new_password" required>
        <button type="submit">Reset Password</button>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $new_password = $_POST['new_password'];

        if (strlen($new_password) < 8) {
            echo "Password harus minimal 8 karakter.";
        } else {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            $update = "UPDATE users SET password = ?, reset_token = NULL, token_expiry = NULL WHERE reset_token = ?";
            $stmt_update = $koneksi->prepare($update);
            $stmt_update->bind_param("ss", $hashed_password, $token);

            if ($stmt_update->execute()) {
                echo "<script>alert('Password berhasil diubah.'); window.location.href='login.php';</script>";
            } else {
                echo "Gagal mengubah password.";
            }
        }
    }
    ?>
</body>
</html>
