<?php
require 'koneksi.php';

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    // Cek token valid
    $stmt = $koneksi->prepare("SELECT * FROM users WHERE reset_token = ? AND token_expiry > NOW()");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Token valid, tampilkan form reset password
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $stmt = $koneksi->prepare("UPDATE users SET password = ?, reset_token = NULL WHERE reset_token = ?");
            $stmt->bind_param("ss", $password, $token);
            if ($stmt->execute()) {
                echo "Password berhasil diperbarui!";
                exit;
            } else {
                echo "Gagal memperbarui password.";
            }
        }
    } else {
        echo "Token tidak valid atau sudah kadaluarsa.";
        exit;
    }
} else {
    echo "Token tidak ditemukan.";
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
    <style type="text/css">
        /* Global style */
        * {
            font-family: "Trebuchet MS", sans-serif;
            box-sizing: border-box;
        }

        /* Header */
        h1 {
            text-transform: uppercase;
            color: #112F91;
            text-align: center;
            margin-top: 20px;
        }

        /* Button styling */
        button {
            background-color: #112F91;
            color: #ffffff;
            padding: 10px 15px;
            text-decoration: none;
            font-size: 14px;
            border: none;
            border-radius: 5px;
            margin-top: 20px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0D2674;
        }

        /* Input styling */
        label {
            font-weight: bold;
            color: #112F91;
        }

        input {
            padding: 10px;
            width: 100%;
            background: #f8f8f8;
            border: 2px solid #ccc;
            outline-color: #112F91;
            border-radius: 5px;
        }

        /* Form container */
        .base {
            width: 400px;
            padding: 20px;
            margin: 40px auto;
            background: #ededed;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <h2>Reset Password</h2>
    <form action="" method="POST">
        <label>Password Baru:</label>
        <input type="password" name="password" required>
        <button type="submit">Reset Password</button>
    </form>
</body>
</html>
