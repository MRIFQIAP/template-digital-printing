-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 01, 2024 at 04:56 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `digitalie`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `produk_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `confirm` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `keranjang`
--

CREATE TABLE `keranjang` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(15) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `image` varchar(255) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `user_id` int(11) DEFAULT NULL,
  `id_produk` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `keranjang`
--

INSERT INTO `keranjang` (`id`, `customer_name`, `address`, `phone`, `quantity`, `total_price`, `image`, `tanggal`, `user_id`, `id_produk`) VALUES
(60, 'mrifqi ap', 'subang aja', '0202202020222', 1, 25000.00, 'uploads/674c7494131ff_673eac0cbfdd1.png', '2024-12-01 14:57:37', 8, 20),
(61, 'mrifqi ap', 'subang aja', '0202202020222', 3, 75000.00, 'uploads/674c867b04cb3_673c35a5ae207.png', '2024-12-01 15:53:31', 8, 20);

-- --------------------------------------------------------

--
-- Table structure for table `order_list`
--

CREATE TABLE `order_list` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `address` varchar(255) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `subtotal` double NOT NULL,
  `total` double NOT NULL,
  `confirm` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_list`
--

INSERT INTO `order_list` (`id`, `fname`, `lname`, `email`, `phone`, `address`, `date`, `subtotal`, `total`, `confirm`, `user_id`) VALUES
(34, 'mrifqi', 'ap', 'mrifqiap@gmail.com', '0202202020222', 'subang aja', '2024-11-18', 798400, 886224, 'sudah', 8),
(35, '', '', '', '', '', '2024-11-22', 0, 0, 'belum', 11),
(36, '', '', '', '', '', '2024-11-22', 0, 0, 'belum', 11),
(37, '', '', '', '', '', '2024-11-22', 0, 0, 'belum', 11),
(38, '', '', '', '', '', '2024-11-25', 0, 0, 'belum', 15),
(39, '', '', '', '', '', '2024-11-28', 0, 0, 'belum', 8),
(40, '', '', '', '', '', '2024-11-28', 0, 0, 'belum', 0);

-- --------------------------------------------------------

--
-- Table structure for table `order_table`
--

CREATE TABLE `order_table` (
  `id` int(11) NOT NULL,
  `cart_id` int(11) NOT NULL,
  `subtotal` double NOT NULL,
  `total` double NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id` int(11) NOT NULL,
  `nama_produk` varchar(255) NOT NULL,
  `deskripsi` varchar(255) NOT NULL,
  `jenis_produk` varchar(11) NOT NULL,
  `harga_jual` int(11) NOT NULL,
  `gambar_produk` varchar(255) NOT NULL,
  `duration` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id`, `nama_produk`, `deskripsi`, `jenis_produk`, `harga_jual`, `gambar_produk`, `duration`) VALUES
(20, 'banner 1X1', 'BANNER INI BERUKURAN 1X1', 'banner', 25000, '673eac7183027.png', 0),
(21, 'sticker', 'sticker paling bagus sedunia', 'sticker', 37500, '673eac0cbfdd1.png', 0),
(22, 'banner 1X3', 'BANNER INI BERUKURAN 1X3', 'banner', 50000, '673eac7b2fc73.png', 0),
(23, 'sticker ', 'sticker paling bagus sedunia', 'sticker', 37500, '673eac00bf178.png', 0),
(24, 'banner 2X2', 'BANNER INI BERUKURAN 2X2', 'banner', 40000, '673eac8377aca.png', 0),
(25, 'sticker ', 'sticker paling bagus sedunia', 'sticker', 55000, '673eac975d57d.png', 0),
(26, 'banner 3X1', 'BANNER INI BERUKURAN 3X1', 'banner', 60000, '673eac9f52f34.png', 0),
(28, 'banner 3X3', 'BANNER INI BERUKURAN 3X3', 'banner', 80000, '673eacae0c9ad.png', 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopping_cart`
--

CREATE TABLE `shopping_cart` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `nama_produk` varchar(255) NOT NULL,
  `harga_jual` double NOT NULL,
  `phone` varchar(150) NOT NULL,
  `address` varchar(255) NOT NULL,
  `confirm` varchar(10) NOT NULL,
  `id_material` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shopping_cart`
--

INSERT INTO `shopping_cart` (`id`, `fname`, `lname`, `nama_produk`, `harga_jual`, `phone`, `address`, `confirm`, `id_material`, `quantity`, `user_id`) VALUES
(25, 'mrifqi', 'ap', 'Poster', 120000, '0202202020222', 'subang aja', 'belum', 2, 2, 8),
(26, 'mrifqi', 'ap', 'Poster', 420000, '0202202020222', 'subang aja', 'belum', 5, 7, 8),
(27, 'mrifqi', 'ap', 'Poster', 120000, '0202202020222', 'subang aja', 'belum', 2, 2, 8);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `id_keranjang` int(11) NOT NULL,
  `tgl_transaksi` datetime NOT NULL,
  `total_pembayaran` int(20) NOT NULL,
  `metode_pembayaran` enum('BANK BRI','DANA') NOT NULL,
  `status_transaksi` enum('bayar','belum bayar') NOT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `id_keranjang`, `tgl_transaksi`, `total_pembayaran`, `metode_pembayaran`, `status_transaksi`, `image`) VALUES
(30, 60, '2024-12-01 15:37:18', 25000, 'DANA', 'bayar', 'bukti_transaksi/674c749e53969.png'),
(31, 60, '2024-12-01 15:57:37', 25000, 'BANK BRI', 'bayar', 'bukti_transaksi/674c79610d838.png'),
(32, 60, '2024-12-01 16:54:33', 100000, 'BANK BRI', 'bayar', 'bukti_transaksi/674c86b9bdcf2.png');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `reset_token` varchar(32) DEFAULT NULL,
  `token_expiry` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `email`, `password`, `phone`, `address`, `role`, `reset_token`, `token_expiry`) VALUES
(3, 'henry', 'tantyo', '', '$2y$10$98tYfLaZT0b7WfYUQoxv8urAgond8c7qDtWzZ2GXpaq3Re5u6alni', '098097777', 'asdasdawr', 'customer', NULL, NULL),
(8, 'mrifqi', 'ap', 'mrifqiap@gmail.com', '$2y$10$f2LKp7jHbjfQ9aL34Y7h9u57vpQSB7S7hZVMeKjY1zz1DFrX0MLEO', '0202202020222', 'subang aja', 'customer', NULL, NULL),
(9, 'mrifqi admin', 'aji', 'justice@gmail.com', '$2y$10$f2LKp7jHbjfQ9aL34Y7h9u57vpQSB7S7hZVMeKjY1zz1DFrX0MLEO', '0202020220', 'subang kota', 'admin', NULL, NULL),
(10, 'hasbi', 'izzan', 'hasbillah@gmail.cpom', '$2y$10$PkiS3yawoq/klR0aqiPf/.ueBqzWtdqak9VQM0koskVbB.U61FLxq', '08111193893', 'subang', 'customer', NULL, NULL),
(11, 'niken', 'des', 'niken@gmail.com', '$2y$10$GqINHSggiHEzSBzxUN/18.8BmtVFN.GbtmVgod/3N/7T7Sw0JpBOa', '0202020202', 'subang bempas\r\n', 'customer', '44fe1b5d89f99a52da259a06a3891f45', NULL),
(12, 'abdul', 'aziz', 'abdul.azis2004.aa@gmail.com', '$2y$10$doV5DB4ZqkCL.ZaM5DFBW.6HiIkTJj5abvbX6tMaez/UYRdhLNyg6', '085320100974', 'kalijati', 'customer', '8cc86dc77455afc6dbecff0964ef8044', NULL),
(13, 'bre', 'trpl', 'bre@gmail.com', '$2y$10$2DAV/7/G5xh5k./ULOB9COAjrKfIFbV5ubvgfzpFUuA.DvVOF0/vK', '0202012315', 'bekasi', 'customer', NULL, NULL),
(14, 'izzan', 'hasbi', 'hasbillahizzan@gmail.com', '$2y$10$jMXeZnKbzn1h3RfvGinXZuVihVK2wU05n0dm70z9r3.Cbd2fbXvBW', '020202033', 'deket yogya', 'customer', 'f9ebffe0e5308741d1cbb88c64951509', NULL),
(15, 'muhammad', 'rifqi', 'mrifqiajipratama@gmail.com', '$2y$10$wgWg4Bg.esFQGS/XpT3L7u6.zWo6DMACS.oYxWAfcdsDocjiLS6MW', '02055963156', 'cimerta', 'customer', '8de7f52aea1b97ad4e7da2ba35a74a18', '2024-11-26 09:33:25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `produk_id` (`produk_id`);

--
-- Indexes for table `keranjang`
--
ALTER TABLE `keranjang`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_keranjang_id_produk` (`id_produk`),
  ADD KEY `fk_keranjang_user_id` (`user_id`);

--
-- Indexes for table `order_list`
--
ALTER TABLE `order_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_table`
--
ALTER TABLE `order_table`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cart_id` (`cart_id`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shopping_cart`
--
ALTER TABLE `shopping_cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `fk_keranjang` (`id_keranjang`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `keranjang`
--
ALTER TABLE `keranjang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `order_list`
--
ALTER TABLE `order_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `order_table`
--
ALTER TABLE `order_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `shopping_cart`
--
ALTER TABLE `shopping_cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`produk_id`) REFERENCES `produk` (`id`);

--
-- Constraints for table `keranjang`
--
ALTER TABLE `keranjang`
  ADD CONSTRAINT `fk_id_produk` FOREIGN KEY (`id_produk`) REFERENCES `produk` (`id`),
  ADD CONSTRAINT `fk_keranjang_id_produk` FOREIGN KEY (`id_produk`) REFERENCES `produk` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_keranjang_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_user_keranjang` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_table`
--
ALTER TABLE `order_table`
  ADD CONSTRAINT `order_table_ibfk_1` FOREIGN KEY (`cart_id`) REFERENCES `cart` (`id`);

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `fk_keranjang` FOREIGN KEY (`id_keranjang`) REFERENCES `keranjang` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
