<?php
include_once 'koneksi.php';
session_start();

// Pastikan pengguna sudah login
if (!isset($_SESSION['id'])) {
    header('Location: login.php');
    exit;
}

// Koneksi ke database
$koneksiObj = new Koneksi();
$koneksi = $koneksiObj->getKoneksi();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'];
    $total_pembayaran = $_POST['totalBayar'];
    $metode_pembayaran = $_POST['metode_pembayaran'];
    $tgl_transaksi = date('Y-m-d H:i:s');
    $status_transaksi = 'Menunggu Konfirmasi'; // Status awal

    // Upload bukti transfer
    $image = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "bukti_transaksi/";
        $file_extension = pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);
        $new_filename = uniqid() . '.' . $file_extension;
        $target_file = $target_dir . $new_filename;

        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            $image = $target_file;
        } else {
            die("Gagal mengupload file.");
        }
    }

    // Ambil id_keranjang dari keranjang yang sesuai dengan user_id
    $sql_keranjang = "SELECT id FROM keranjang WHERE user_id = ? LIMIT 1";
    $stmt_keranjang = $koneksi->prepare($sql_keranjang);
    $stmt_keranjang->bind_param("i", $user_id);
    $stmt_keranjang->execute();
    $result_keranjang = $stmt_keranjang->get_result();
    
    // Cek apakah keranjang ditemukan
    if ($result_keranjang->num_rows === 0) {
        die("Tidak ada data keranjang untuk pengguna ini. Silakan tambahkan barang ke keranjang terlebih dahulu.");
    }

    $row_keranjang = $result_keranjang->fetch_assoc();
    $id_keranjang = $row_keranjang['id'];

    // Simpan data transaksi ke database
    $sql = "INSERT INTO transaksi (id_keranjang, tgl_transaksi, total_pembayaran, metode_pembayaran, status_transaksi, image) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $koneksi->prepare($sql);
    
    // Cek apakah prepare berhasil
    if ($stmt === false) {
        die("Prepare failed: " . $koneksi->error);
    }

    // Bind parameter dan eksekusi query
    $stmt->bind_param("isdsss", $id_keranjang, $tgl_transaksi, $total_pembayaran, $metode_pembayaran, $status_transaksi, $image);

    if ($stmt->execute()) {
        // Ambil ID transaksi
        $id_transaksi = $stmt->insert_id;

        if ($id_transaksi) {
            echo "Transaksi berhasil dengan ID: " . $id_transaksi . "<br>";  // Menampilkan ID transaksi
        } else {
            echo "Gagal mendapatkan ID transaksi.<br>";
        }

        // Redirect ke halaman nota
        header("Location: nota.php?id=" . $id_transaksi);
        exit;
    } else {
        echo "Error: " . $stmt->error . "<br>";  // Menampilkan error jika query gagal
    }
} else {
    header('Location: checkout.php');
    exit;
}
?>
