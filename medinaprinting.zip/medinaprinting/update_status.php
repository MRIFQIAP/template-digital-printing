<?php
include 'koneksi.php';

$koneksiObj = new Koneksi();
$koneksi = $koneksiObj->getKoneksi();

// Proses update status jika ada permintaan via AJAX
if (isset($_POST['id']) && isset($_POST['status'])) {
    $id_transaksi = $_POST['id'];
    $status = $_POST['status'];

    $sql_update = "UPDATE transaksi SET status_transaksi = ? WHERE id_transaksi = ?";
    $stmt = $koneksi->prepare($sql_update);
    $stmt->bind_param("si", $status, $id_transaksi);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Status berhasil diubah.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Gagal mengubah status.']);
    }
    exit;
}
?>
