<?php
class Produk {
    private $db;

    public function __construct($dbConnection) {
        $this->db = $dbConnection;
    }

    public function deleteData($id) {
        $query = "DELETE FROM produk WHERE id = ?";
        $stmt = $this->db->prepare($query);

        if ($stmt) {
            $stmt->bind_param("i", $id);
            return $stmt->execute();
        }
        return false;
    }
}
?>
