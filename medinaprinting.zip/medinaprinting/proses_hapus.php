<?php
include 'koneksi.php';
include 'crudbarang.php';

// Membuat koneksi dan objek produk
$koneksiObj = new Koneksi();
$db = $koneksiObj->getKoneksi();
$produk = new produk($db);

// Ambil ID produk dari URL
$id = isset($_GET['id']) ? $_GET['id'] : null;

if ($id) {
    $hasil = $produk->deleteData($id);
    if ($hasil) {
        echo "<script>alert('Produk berhasil dihapus.');window.location='data_barang.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus produk.');window.location='data_barang.php';</script>";
    }
} else {
    echo "<script>alert('ID Produk tidak ditemukan.');window.location='data_barang.php';</script>";
}
?>
