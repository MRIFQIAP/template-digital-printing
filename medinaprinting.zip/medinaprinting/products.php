<?php
include_once 'koneksi.php';
session_start();

// Membuat objek koneksi
$koneksiObj = new Koneksi(); 
$koneksi = $koneksiObj->getKoneksi();

// Validasi koneksi
if (!$koneksi) {
    die("Koneksi gagal: " . $koneksiObj->error);
}

// Periksa status login
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

// Mendapatkan kategori dari URL (default 'all' jika tidak ada)
$current_category = isset($_GET['category']) ? $_GET['category'] : 'all';

// Membuat query berdasarkan kategori
if ($current_category != 'all') {
    $query = "SELECT * FROM produk WHERE jenis_produk = ? ORDER BY id ASC";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("s", $current_category);
} else {
    $query = "SELECT * FROM produk ORDER BY id ASC";
    $stmt = $koneksi->prepare($query);
}

// Eksekusi query
$stmt->execute();
$result = $stmt->get_result();

// Query user berdasarkan sesi
$userStmt = $koneksi->prepare("SELECT id, fname, lname, email, role FROM users WHERE id = ?");
$userStmt->bind_param("i", $_SESSION['id']);
$userStmt->execute();
$userResult = $userStmt->get_result();
$userData = $userResult->fetch_assoc(); // Data user aktif

?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/font/font-face.css">
    <link rel="stylesheet" href="bootstrap_custom.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <title>Produk | Medina Printing</title>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-md navbar-light px-6 font-regular" id="navbar">
        <div class="container-fluid">
            <a class="navbar-brand" href="main.php">
                <img src="assets/logo.svg" alt="" width="200">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <!-- navbar menu -->
            <div class="collapse navbar-collapse" id="navbarsExample04">
                <ul class="navbar-nav mx-auto mb-2 mb-md-0">
                    <?php { ?>
                    <li class="nav-item mx-2">
                    <a class="nav-link" aria-current="page" href="main.php">Beranda</a>
                    </li>
                    <li class="nav-item mx-2">
                    <a class="nav-link" href="#jump-ourproduct">Produk</a>
                    </li>
                    <li class="nav-item mx-2">
                    <a class="nav-link" href="main.php#jump-ourstore">Toko</a>
                    </li>
                    <li class="nav-item mx-2">
                    <a class="nav-link" href="main.php#jump-contact">Kontak</a>
                    </li>
                    <li class="nav-item mx-2">
                    <a class="nav-link" href="main.php#jump-aboutus">Tentang Kami</a>
                    </li>
                    <?php } ?>
                </ul>
                </li>
                </ul>
                <!-- language and search button -->
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown font-semibold text-black" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            ID
                        </a>
                        <ul class="dropdown-menu dropdown-menu-light" aria-labelledby="navbarDarkDropdownMenuLink">
                            <li><a class="dropdown-item" href="#" onclick="id_language();">ID</a></li>
                        </ul>
                    </li>
                    <li class="nav-item mx-2">
                        <a class="nav-link" id="search-button" href="#searchForm" data-target="#searchForm" role="button" aria-expanded="false" data-bs-toggle="collapse">
                            <i class="fa fa-search"></i>
                            <i class="fa fa-close text-danger"></i>
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <div class="input-group collapse" id="searchForm">
                            <input type="text" class="form-control rounded-pill" placeholder="Search" aria-label="Search" aria-describedby="basic-addon2">
                            <div class="input-group-append collapse" id="cari">
                                <button class="btn btn-outline-secondary" id="cari" type="button"><i class="fa fa-search" aria-hidden="true" aria-controls="searchForm"></i></button>
                            </div>
                        </div>
                    </li>
                    <!-- login/register -->
                    <li class="nav-item dropdown mx-2">
                        <a class="nav-link dropdown font-semibold text-black" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php
                            if (isset($_SESSION['role']) && $_SESSION['role']) {
                                if (isset($userData['fname'])) { // Gunakan $userData sebagai variabel yang benar
                                    echo "<button class='btn btn-sm font-medium button-theme text-light rounded-pill px-3' type='button'>Hello, " . htmlspecialchars($userData['fname'], ENT_QUOTES, 'UTF-8') . "!</button>";
                                } else {
                                    echo "<button class='btn btn-sm font-medium button-theme text-light rounded-pill px-3' type='button'>Hello, User!</button>";
                                }
                            } else {
                                echo "<button class='btn btn-sm font-medium button-theme text-light rounded-pill px-3' type='button'>Hello, Guest!</button>";
                            }
                            ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-light" aria-labelledby="navbarDarkDropdownMenuLink">
                            <?php if (isset($_SESSION['role']) && $_SESSION['role']) {
                            ?>
                                <?php
                                echo "<li><a class='dropdown-item' href='quotation.php'>Quotation</a></li><li><a class='dropdown-item' href='logout.php'>Logout</a></li> ";
                                ?>
                            <?php } else { ?>
                                <li><a class="dropdown-item" href="login.php">Login</a></li>
                                <li><a class="dropdown-item" href="register.php">Register</a></li>
                            <?php }  ?>
                        </ul>
                    </li>
                    <!-- Shopping Cart -->
                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] == "customer") {
                    ?>
                        <?php
                        echo "<li class='nav-item'>
                            <a class='nav-link position-relative btn btn-sm font-medium button-theme2 rounded-3' type='button' href='keranjang.php'>Keranjang <i class='fa fa-shopping-cart' aria-hidden='true'></i></a></li>";
                        ?>
                    <?php } else { ?>
                    <?php }  ?>
                    <!-- order list (admin only) -->
                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] == "admin") {
                    ?>
                        <?php
                        echo "<li class='nav-item mx-2'>
                        <a class='nav-link position-relative btn btn-sm font-medium button-theme2 rounded-3' type='button' href='order_list.php'>Order <i class='fa fa-list-alt' aria-hidden='true'></i><span class='position-absolute top-0 start-100 translate-middle p-2 bg-danger border border-light rounded-circle'><span class='visually-hidden'>New alerts</span></a></li>";
                        ?>
                    <?php } else { ?>
                    <?php }  ?>
            </div>
        </div>
    </nav>
    <!-- endnavbar -->

    <!-- carousel -->
    <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>

        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="assets/carousel/carousel1.jpg" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="assets/carousel/carousel2.jpg" class="d-block w-100" alt="...">
            </div>

        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>



    <div class="container bg">
        <div class="row">
            <!-- sidebar -->
            <div class="col-md-3 py-5">
                <!-- category sidebar -->
                <div class="header font-semibold ps-2 fs-5" style="margin-bottom: 1.2rem;">
                    kategori
                </div>
                <div class="card rounded-3 py-1 scroll-sidebar" style="width: 15rem;">
                    <ul class="list-group list-group-flush font-regular text-center">
                        <li class="list-group-item border-0">
                            <a href="products.php?category=all" class="text-decoration-none px-2 <?= $current_category == 'all' ? 'blue-theme' : 'text-black' ?>">Semua Produk</a>
                        </li>
                        <li class="list-group-item border-0">
                            <a href="products.php?category=banner" class="text-decoration-none px-2 <?= $current_category == 'banner' ? 'blue-theme' : 'text-black' ?>">Banner</a>
                        </li>
                        <li class="list-group-item border-0">
                            <a href="products.php?category=sticker" class="text-decoration-none px-2 <?= $current_category == 'sticker' ? 'blue-theme' : 'text-black' ?>">Sticker</a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- catalogue -->
            <div class="col-md-9">
                <!-- header and carousel -->
                <div class="header font-semibold py-3 fs-2 text-end">
                    Produk Kami
                </div>

                <!-- product cards -->
                <div class="row row-cols-1 row-cols-md-3 g-4 py-3 mb-5">
                    <?php
                    if ($result->num_rows > 0) {
                        while ($p = $result->fetch_assoc()) {
                    ?>
                            <div class="col d-flex justify-content-center">
                                <div class="card h-100 rounded-3 img-hover-zoom text-center">
                                    <a href="pesanan.php?id=<?= $p['id'] ?>">
                                        <img src="gambar/<?php echo $p['gambar_produk']; ?>" class="card-img-top py-3 px-3" alt="...">
                                    </a>
                                    <div class="card-body d-flex flex-column justify-content-between">
                                        <a href="#" class="text-decoration-none text-black blue-hover">
                                            <h5 class="card-title font-medium"><?php echo $p['nama_produk']; ?></h5>
                                            <h4 class="card-price font-bold">Rp. <?php echo number_format($p['harga_jual'], 0, ',', '.'); ?></h4>
                                        </a>
                                        <p class="card-text font-regular text-secondary"><?php echo $p['deskripsi']; ?></p>
                                        <div class="d-flex justify-content-center">
                                            <div class="rating font-regular">
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                3.0
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    <?php 
                        }
                    } else { 
                    ?>
                        <p>Produk tidak ada</p>
                    <?php 
                    } 
                    ?>
                </div>
            </div>
        </div>
    </div>




    <footer>
        <img src="assets/footer.svg" alt="" width="100%">
        <nav class="navbar bottom navbar-expand-sm navbar-dark blue-background px-6 pb-3">
            <div class="container-fluid">
                <a class="navbar-brand" href="#"><img src="assets/logo_footer.svg" width="60%" alt=""></a>
                <div class="text-light font-regular">© Copyright 2024. Design of Medina Printing (Kelompok 1)</div>

                <ul class="navbar-nav">
                    <li class="nav-item dropup mx-2">
                        <a class="nav-link dropup font-semibold text-light" href="#" id="navbarDarkDropdownMenuLinkBottom" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            ID
                        </a>
                        <ul class="dropdown-menu dropdown-menu-light" aria-labelledby="navbarDarkDropdownMenuLink">
                            <li><a class="dropdown-item" href="#" onclick="id_language();">ID</a></li>
                        </ul>
                    </li>
                    <li class="nav-item mx-2">
                        <a class="nav-link" id="search-button" href="#searchForm" data-target="#searchForm" role="button" aria-expanded="false" data-bs-toggle="collapse">
                            <i class="fa fa-search text-light"></i>
                            <i class="fa fa-close text-light"></i>
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <div class="input-group collapse" id="searchForm">
                            <input type="text" class="form-control rounded-pill" placeholder="Search" aria-label="Search" aria-describedby="basic-addon2">
                            <div class="input-group-append collapse" id="cari">
                                <button class="btn btn-outline-secondary" id="cari" type="button"><i class="fa fa-search" aria-hidden="true" aria-controls="searchForm"></i></button>
                            </div>
                        </div>
                    </li>
                </ul>

            </div>
        </nav>
    </footer>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="script.js"></script>

</body>

</html>