<?php
include_once 'koneksi.php';
session_start();

// Pastikan pengguna sudah login
if (!isset($_SESSION['id'])) {
    header('Location: login.php');
    exit;
}

// Cek role pengguna
if ($_SESSION['role'] != "customer") {
    header('Location: login.php');
    exit;
}

// Koneksi ke database
$koneksiObj = new Koneksi();
$koneksi = $koneksiObj->getKoneksi();

// Logika untuk menghapus data dari keranjang
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['hapus'])) {
    $id = intval($_POST['id']); 

    // Query untuk menghapus data berdasarkan ID
    $sql = "DELETE FROM keranjang WHERE id = ? AND user_id = ?";
    $stmt = $koneksi->prepare($sql);
    $stmt->bind_param('ii', $id, $_SESSION['id']);
    if ($stmt->execute()) {
        echo "<script>alert('Item berhasil dihapus dari keranjang!'); window.location.href='keranjang.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus item!'); window.location.href='keranjang.php';</script>";
    }
    $stmt->close();
}

// Query untuk mengambil data keranjang dan nama produk berdasarkan user_id
$sql = "
    SELECT keranjang.*, produk.nama_produk, produk.harga_jual 
    FROM keranjang 
    INNER JOIN produk ON keranjang.id_produk = produk.id 
    WHERE keranjang.user_id = ?";
$stmt = $koneksi->prepare($sql);
$stmt->bind_param('i', $_SESSION['id']);
$stmt->execute();
$result = $stmt->get_result();

// Variabel untuk menghitung total bayar
$totalBayar = 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Keranjang Belanja</title>
    <style>
        /* Global Styles */
        * {
            font-family: "Trebuchet MS", sans-serif;
            box-sizing: border-box;
        }

        body {
            background-color: #f4f7fc;
            margin: 0;
            padding: 0;
        }

        h1 {
            text-transform: uppercase;
            color: #112F91;
            text-align: center;
            margin-top: 20px;
            font-size: 2em;
        }

        /* Table Styling */
        table {
            border: 1px solid #112F91;
            border-collapse: collapse;
            width: 80%;
            margin: 20px auto;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        table thead th {
            background-color: #112F91;
            border: 1px solid #0D2674;
            color: #ffffff;
            padding: 12px;
            text-align: left;
            text-transform: uppercase;
        }

        table tbody tr:nth-child(even) {
            background-color: #E1E6F9;
        }

        table tbody tr:hover {
            background-color: #B3BCF2;
            cursor: pointer;
        }

        table tbody td {
            border: 1px solid #112F91;
            padding: 12px;
            text-align: left;
        }

        /* Button Styling */
        a, button {
            background-color: #112F91;
            color: #ffffff;
            padding: 10px 15px;
            text-decoration: none;
            font-size: 14px;
            border-radius: 5px;
            margin: 5px;
            display: inline-block;
            transition: background-color 0.3s;
        }

        a:hover, button:hover {
            background-color: #0D2674;
        }

        .center {
            text-align: center;
            margin: 20px 0;
        }

        .btn-action {
            background-color: #112F91;
            color: #ffffff;
            padding: 10px 15px;
            text-decoration: none;
            font-size: 14px;
            border-radius: 5px;
            margin: 5px;
            display: inline-block;
            transition: background-color 0.3s;
            border: none;
            cursor: pointer;
        }

        .btn-action:hover {
            background-color: #0D2674;
        }

        form {
            display: inline-block;
            margin: 0;
        }
    </style>
</head>
<body>
    <h1>Keranjang Belanja</h1>
    <br/>
    <?php if ($result && $result->num_rows > 0): ?>
        <table>
            <thead>
            <tr>
                <th>No</th>
                <th>Nama Produk</th>
                <th>Quantity</th>
                <th>Harga Satuan</th>
                <th>Total Harga</th>
                <th>Design</th>
                <th>Aksi</th>
            </tr>
            </thead>
            <tbody>
                <?php $no = 1; while ($row = $result->fetch_assoc()): ?>
                    <tr>
                         <td><?= $no++; ?></td>
                    <td><?= htmlspecialchars($row['nama_produk']); ?></td>
                    <td><?= htmlspecialchars($row['quantity']); ?></td>
                    <td>Rp<?= number_format($row['harga_jual'], 0, ',', '.'); ?></td>
                    <td>Rp <?= number_format($row['total_price'], 0, ',', '.'); ?></td>
                        <td style="text-align: center;">
                            <img src="<?= htmlspecialchars($row['image']); ?>" alt="image" style="width: 50px; height: 50px;">
                        </td>
                        <td>
                            <form action="keranjang.php" method="POST" style="display:inline;">
                                <input type="hidden" name="id" value="<?= $row['id']; ?>">
                                <button type="submit" name="hapus" class="btn-action" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    <?php
                    // Menambahkan total harga ke total bayar
                    $totalBayar += $row['total_price'];
                    endwhile;
                    ?>
            </tbody>
        </table>

        <!-- Menampilkan Total Bayar -->
        <div class="center" style="margin-top: 10px;">
            <strong>Total Bayar: </strong> Rp <?= number_format($totalBayar, 0, ',', '.'); ?>
        </div>

        <div class="center">
            <form action="checkout.php" method="post" style="display: inline-block;">
                <input type="hidden" name="user_id" value="<?= $_SESSION['id']; ?>">
                <button type="submit" class="btn-action">Check Out</button>
            </form>
            <a href="main.php" class="btn-action">Kembali ke Beranda</a>
        </div>
    <?php else: ?>
        <p class="center" style="color: #112F91;">Keranjang Anda kosong. Silakan tambahkan produk terlebih dahulu.</p>
        <div class="center">
            <a href="main.php" class="btn-action">Kembali ke Beranda</a>
        </div>   
        <?php endif; ?>
</body> 
</html>
